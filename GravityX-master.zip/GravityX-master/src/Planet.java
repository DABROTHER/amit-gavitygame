
public class Planet {
	
	/* Position */
	int x;
	int y;
	int mass = 500;
	int size = 128;
	
	public Planet(int posX, int posY){
		x = posX;
		y = posY;
		
	}
	
	
}
