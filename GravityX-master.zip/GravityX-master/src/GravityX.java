
import java.util.ArrayList;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;




/**
 * 
 *
 */

 
public class GravityX extends Application 
{
	
	/* Final */
	public static final int SCREENWIDTH = 1280;
	public static final int SCREENHEIGHT = 800;
	
	/* Global time*/
	
	public int time = 0;
	
	/* Canvas */
	Canvas canvas;
	GraphicsContext context;
	
	/* Import graphics */
	
	Image background = new Image( "Graphics/background.png" );
	
	Image bullet = new Image( "Graphics/bullet.png" );
	Image planet = new Image( "Graphics/planet.png" );
	
	Image shipRight = new Image( "Graphics/ShipRight.png" );
	Image shipLeft = new Image( "Graphics/ShipLeft.png" );
	Image shipUp = new Image( "Graphics/ShipUp.png" );
	Image shipDown = new Image( "Graphics/ShipDown.png" );
	
	/* Key States */
	
	public Boolean up = false;
	public Boolean down = false;
	public Boolean left = false;
	public Boolean right = false;
	public Boolean spaceBar = false;
	
	//Initialize Sprites
    
    Ship player = new Ship(SCREENWIDTH/16,SCREENHEIGHT/2);
    
    ArrayList<Planet> planets = new ArrayList<Planet>();
    
    ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
	
	
	/* Main method */
	
    public static void main(String[] args) 
    {
        launch(args);
    }
    
    /* Start the stage */
    
    public void start(Stage theStage) 
    {
        /* Canvas initialization */
    	
    	theStage.setTitle( "Gravity X" );
             
        Group root = new Group();
        Scene theScene = new Scene( root );
        theStage.setScene( theScene ); 
        canvas = new Canvas( SCREENWIDTH, SCREENHEIGHT ); //Set resolution
        root.getChildren().add( canvas );      
        context = canvas.getGraphicsContext2D();
        
        /*
         * Controls
         */
        
        /*
         * Update values when keys pressed.
         */
        
        EventHandler pressed = new EventHandler<KeyEvent>() {
        	   @Override
        	   public void handle(KeyEvent event) {
        		   
        	       if (event.getCode().equals(KeyCode.SPACE)){
        	    	   spaceBar = true;
        	    	   System.out.println("SPACEBAR pressed");
        	       } 
        	       if (event.getCode().equals(KeyCode.LEFT)){
        	    	   left = true;
        	    	   System.out.println("LEFT pressed");
        	       } 
        	       if (event.getCode().equals(KeyCode.RIGHT)){
        	    	   right = true;
        	    	   System.out.println("RIGHT pressed");
        	       } 
        	       if (event.getCode().equals(KeyCode.UP)){
        	    	   up = true;
        	    	   System.out.println("UP pressed");
        	       }
        	       if (event.getCode().equals(KeyCode.DOWN)){
        	    	   down = true;
        	    	   System.out.println("DOWN pressed");
        	       } 
        	       
        	   }
        	};
        theStage.getScene().setOnKeyPressed(pressed);
        
        /*
         * Update values when keys released.
         */
        
        EventHandler released = new EventHandler<KeyEvent>() {
        		@Override
        		public void handle(KeyEvent event) {
  
        			if (event.getCode().equals(KeyCode.SPACE)){
        				spaceBar = false;
        				System.out.println("SPACEBAR released");
        			} 
        			if (event.getCode().equals(KeyCode.LEFT)){
         	    	   left = false;
         	    	   System.out.println("LEFT released");
         	        } 
         	        if (event.getCode().equals(KeyCode.RIGHT)){
         	    	   right = false;
         	    	   System.out.println("RIGHT released");
         	        } 
         	        if (event.getCode().equals(KeyCode.UP)){
         	    	   up = false;
         	    	   System.out.println("UP released");
         	        }
         	        if (event.getCode().equals(KeyCode.DOWN)){
         	    	   down = false;
         	    	   System.out.println("DOWN released");
         	       } 	
     	       
        		}
        	};
        theStage.getScene().setOnKeyReleased(released);
        
        
        ///////////////////////////////////////////////////////////////
        
        
        
        final long startNanoTime = System.nanoTime();
        
        new AnimationTimer()
        {
            public void handle(long currentNanoTime)
            {	
            	
            	/* Get scene time in seconds*/
            	double timeDouble = (currentNanoTime - startNanoTime) / 1000000000.0;  
            	int t = (int) timeDouble;
            	//System.out.println(t);
            	
                /* Update scene */
                scene(t);
                
            }
            
        }.start();
        
        
        
        theStage.show();
    }
    
    
    /*
     * Create the scene.
     * @param double t current running time.
     */
    
    public void scene(int t){
    	
    	
    	/* Clear previous scene and draw background. */
    	context.clearRect(0, 0, SCREENWIDTH, SCREENHEIGHT);
        context.drawImage(background,0, 0);
    	/* Handle Player */
    	//Update position
    	if(up == true){
    		player.y -= player.speed;
    		player.orientation = "up";
    	}
    	if(down == true){
    		player.y += player.speed;
    		player.orientation = "down";
    	}
    	if(left == true){
    		player.x -= player.speed;
    		player.orientation = "left";
    	}
    	if(right == true){
    		player.x += player.speed;
    		player.orientation = "right";
    	}
    	//draw the correct image depending on state
    	if(player.orientation.equals("right")){
    		context.drawImage( shipRight, player.x, player.y );
    	}else if(player.orientation.equals("left")){
    		context.drawImage( shipLeft, player.x, player.y );
    	}else if(player.orientation.equals("up")){
    		context.drawImage( shipUp, player.x, player.y );
    	}else if(player.orientation.equals("down")){
    		context.drawImage( shipDown, player.x, player.y );
    	}
        
    	/* Generate random planets */
    	
    	if (time%7 == 0 && time != t){
    		Random r = new Random();
    		int low = SCREENWIDTH;
    		int high = SCREENWIDTH + 125;
    		int x = r.nextInt(high-low) + low;
    		
    		low = 0;
    		high =SCREENHEIGHT;
    		int y = r.nextInt(high-low) + low;
    		
    		Planet tempPlanet = new Planet(x,y);
    		planets.add(tempPlanet);
    		
    	}
    	
    	/* Check for collition between player and planets */
    	
    	for (int i = 0; i < planets.size(); i++) {
    		planets.get(i).x -= 1;
    		if (player.x > planets.get(i).x && player.x < planets.get(i).x + planets.get(i).size && player.y > planets.get(i).y && player.y < planets.get(i).y + planets.get(i).size){
    			player.collition = true;
    			planets.remove(i);
    			
    		}
		}
    	
    	if (player.collition){
    		//TODO: end game.
    		//System.out.println("Ship destroyed.");
    	}
    	
    	/* Remove planets no longer on the Screen */
    	for (int i = 0; i < planets.size(); i++) {
    		if(planets.get(i).x < -128 || planets.get(i).x > (SCREENWIDTH + 128) || planets.get(i).y < -128 || planets.get(i).y > (SCREENHEIGHT+128)){
    			planets.remove(i);
    		}
			
		}
    	
    	/* Update planets position */
    	
    	for (Planet temp : planets){
    		temp.x -= 1;
		}
    	
    	/* Draw planets */
    	
    	for (Planet temp : planets){
    		context.drawImage(planet, temp.x, temp.y);
		}
    	
    	/* Create projectiles */
    	
    	if(spaceBar == true){
    		Projectile temp = new Projectile(player.x + 32,player.y + 32 ,player.orientation);
    		projectiles.add(temp);
    	}
    	
    	/* Remove projectiles no longer on the Screen */
    	for (int i = 0; i < projectiles.size(); i++) {
    		if(projectiles.get(i).x < -128 || projectiles.get(i).x > (SCREENWIDTH + 128) || projectiles.get(i).y < -128 || projectiles.get(i).y > (SCREENHEIGHT+128)){
    			projectiles.remove(i);
    		}
			
		}
    	
    	
    	/* Update Projectiles */
    	
    	for (Projectile temp : projectiles){
    		if (temp.orientation.equals("right")){
    			temp.x += temp.speed;
    		}else if (temp.orientation.equals("left")){
    			temp.x -= temp.speed;
    		}else if (temp.orientation.equals("up")){
    			temp.y -= temp.speed;
    		}else if (temp.orientation.equals("down")){
    			temp.y += temp.speed;
    		}
		}
    	
    	/* Check for collition between projectiles and planets */
    	
    	for (int i = 0; i < planets.size(); i++) {
    		//TODO: fix
    		for (int j = 0; j < projectiles.size(); j++) {
    			if (projectiles.get(j).x > planets.get(i).x && projectiles.get(j).x < planets.get(i).x + planets.get(i).size && projectiles.get(j).y > planets.get(i).y && projectiles.get(j).y < planets.get(i).y + planets.get(i).size){
       
        			planets.remove(i);
        			projectiles.remove(j);
        			
        		}
    		}
    		
		}
    	
    	
    	
    	/* Draw Projectiles */
    	
    	for (Projectile temp : projectiles){
    		context.drawImage(bullet, temp.x, temp.y);
		}
    	

    	/* Update time at the end of the scene */
    	
    	time = t;
    }
     
    
    
}




