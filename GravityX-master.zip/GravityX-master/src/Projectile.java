
public class Projectile {
	
	/* Position */
	int x;
	int y;
	int speed = 10;
	String orientation;
	
	public Projectile(int posX, int posY, String orientation){
		x = posX;
		y = posY;
		this.orientation = orientation;
		
	}
	
}
