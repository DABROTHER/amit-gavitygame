
public class Ship{
	
	/* Position */
	int x;
	int y;
	int speed = 5;
	boolean collition = false;
	
	/* State */
	
	String orientation = "right";
	
	public Ship(int posX, int posY){
		x = posX;
		y = posY;
		
	}
}
